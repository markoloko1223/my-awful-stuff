How to open:
-Make sure you have python installed (do "py" in cmd, if it pops up with the version info then you're good to go)
-Open CMD (in the search bar type "cmd" or press windows+r and type cmd)
-Unzip the file you dummy
-In CMD type "py (drag the file to cmd)"
thats it

do not claim it as yours or i will come to your house and steal your liver