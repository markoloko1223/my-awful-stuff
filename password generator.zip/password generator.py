#libraries
import random

#characters
lowercase = "abcdefghijklmnopqrstuvwxyz"
uppercase = "ABCDEFGHIJKLMNOPQRSTUWXHYZ"
numbers = "0123456789"
symbols = "!@#$%^&*()+-_="
characters = lowercase + uppercase + numbers + symbols

#code
def passgen():
    #options for user
    password_length = int(input("Numbers of characters in password (int): "))
    password = ""
    for i in range(password_length):
        random_character = random.choice(characters)
        password = password + random_character
    print("Your password is: " + password)
    answer = input("Do you want to generate another password? (y/n): ")
    if answer == "n":
        print("ok, thanks for using my pass gen. made by Xiao Ling (not the racist one)#2043 if you want the source code, just open the file in some text editor")
    return answer
answer = passgen()
#check if user wants another pass
if answer == "y":
    passgen()
